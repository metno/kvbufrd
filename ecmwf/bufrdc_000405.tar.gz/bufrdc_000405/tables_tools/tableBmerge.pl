use strict;
# this script is not working it is in early dev stage

my $filein=@ARGV[0];
open(IN,"<$filein") or die "$filein: $!";

my $line;
my $count=0;
while (defined ($line = <IN>)) {
	chomp $line;
	$count++;
	$line =~ /( )(\d{6}) (.{64})(.)(.{24}) ([\-\+0-9 ]{3}) ([\-\+0-9 ]{12}) ([\-\+0-9 ]{3})( (.{22}) ([\+\-0-9 ]{4}) ([0-9 ]{9}))?/g or die "$filein wrong format at line $count \n\"$line\"\n";
  print "$2\n";
  print "$3\n";
  print "$5\n";
  print "$6\n";
  print "$7\n";
  print "$8\n";
  print "$10\n";
  print "$11\n";
  print "$12\n";
}
close(IN);

