#!/bin/sh
set -ex

path=`pwd`

export TOOLS=examples/


BUFR_TABLES=$path/bufrtables/
BUFR_TABLES=/var/tmp/mac/p4/bufrdc/releases/bufrtables/
export BUFR_TABLES

$TOOLS/bufr_decode_all -i data/temp_101.bufr | sed '/bufrtables/ d' | sed '/BUFR DECODING SOFTWARE VERSION/d'  > test.log
$TOOLS/bufr_decode_all -i data/syno_1.bufr   | sed '/bufrtables/ d' | sed '/BUFR DECODING SOFTWARE VERSION/d' >> test.log
$TOOLS/bufr_decode_all -i data/airc_142.bufr | sed '/bufrtables/ d' | sed '/BUFR DECODING SOFTWARE VERSION/d' >> test.log

set +e

diff test.log test.log.good
if [ $? != 0 ]
then
	echo "****************************************"
	echo "****************************************"
	echo TEST $0 FAILED              
	echo "****************************************"
	echo "****************************************"
	exit 1
fi

set +e
for f in sapp_sample/*.bufr data/*.bufr
do
	echo $TOOLS/bufr_decode_all -i $f
	$TOOLS/bufr_decode_all -i $f > /dev/null


	if [ $? != 0 ]
	then
		echo "****************************************"
		echo "****************************************"
		echo TEST $0 FAILED              
		echo "****************************************"
		echo "****************************************"
		exit 1
	fi

done
rm -f test.log
