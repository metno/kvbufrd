#define fortint int
#define INTEGER_MIN INT_MIN
#define JBPW_DEF 32
